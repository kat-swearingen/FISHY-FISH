import pygame
import random

pygame.init()
pygame.display.set_caption("fishy fish doing the fishy fish thing")
screen = pygame.display.set_mode((700,500))
clock = pygame.time.Clock()

#blueprint for a brick
class fish:
  def __init__(self): #constructor: MAKES the brick
    self.xpos = random.randrange(0,500)
    self.ypos = random.randrange(0,500)
    self.xVel = 1
    self.yVel = 1
    #check the C++ code for a few other variables here

  def draw(self):
    pygame.draw.ellipse(screen, (177,0,0), (self.xpos, self.ypos, 100, 40))
    pygame.draw.polygon(screen, (177,0,0), ((self.xpos+180, self.ypos+100), (self.xpos+150, self.ypos+60), (self.xpos+150, self.ypos+150)))

  def move(self):
    #this needs more code here
    self.xpos+=self.xVel
    self.ypos+=self.yVel


f1 = fish()
f2=fish()
f3=fish()

f1.colide()
f2.colide()
f3.colide()

while True:
  f1.move()
  f2.move()
  f3.move()

  #render section
  screen.fill((0,0,0))
  f1.draw()
  f2.draw()
  f3.draw()
  pygame.display.flip()

  #def colide(self, x, y): #x and y are the ball's position
   # if self.xpos

#end game loop--------------------------------------------
pygame.quit()